import json

import pytest

from local_ai_hub.vision_contracts import (
    FrontendReviewBundle,
    build_coder_packet,
    parse_vision_result,
)


def test_bundle_requires_screenshot_and_preserves_full_dom() -> None:
    bundle = FrontendReviewBundle.from_payload(
        {
            "schema_version": "1",
            "source": "current_tab",
            "prompt": "Why is the CTA hidden?",
            "screenshot": {"artifact_id": "art_img", "mime_type": "image/png"},
            "dom": {"artifact_id": "art_dom", "redaction": "none"},
        }
    )

    assert bundle.screenshot_artifact_id == "art_img"
    assert bundle.dom_artifact_id == "art_dom"
    assert bundle.dom_redaction == "none"


def test_bundle_rejects_missing_screenshot() -> None:
    with pytest.raises(ValueError, match="screenshot"):
        FrontendReviewBundle.from_payload(
            {"schema_version": "1", "source": "upload", "prompt": "Review"}
        )


@pytest.mark.parametrize("redaction", ["content", "semantic", "pii", ""])
def test_bundle_rejects_semantic_dom_redaction(redaction: str) -> None:
    with pytest.raises(ValueError, match="redaction"):
        FrontendReviewBundle.from_payload(
            {
                "screenshot": {"artifact_id": "art_img", "mime_type": "image/png"},
                "dom": {"redaction": redaction},
            }
        )


def test_bundle_rejects_missing_dom_redaction_marker() -> None:
    with pytest.raises(ValueError, match="redaction"):
        FrontendReviewBundle.from_payload(
            {
                "screenshot": {"artifact_id": "art_img", "mime_type": "image/png"},
                "dom": {"artifact_id": "art_dom"},
            }
        )


def test_bundle_rejects_oversized_inline_prompt() -> None:
    with pytest.raises(ValueError, match="exceeds"):
        FrontendReviewBundle.from_payload(
            {
                "prompt": "x" * 2_001,
                "screenshot": {"artifact_id": "art_img", "mime_type": "image/png"},
            }
        )


def test_bundle_forwards_network_runtime_artifact_id() -> None:
    bundle = FrontendReviewBundle.from_payload(
        {
            "screenshot": {"artifact_id": "art_img", "mime_type": "image/png"},
            "runtime": {
                "console_artifact_id": "console-1",
                "network_artifact_id": "network-1",
            },
        }
    )

    assert bundle.runtime_artifact_id == "console-1"
    assert bundle.network_artifact_id == "network-1"


def test_vision_result_accepts_fenced_json_and_clamps_confidence() -> None:
    result = parse_vision_result(
        "```json\n"
        '{"summary":"bad CTA","findings":[{"id":"f1",'
        '"severity":"high","category":"layout","problem":"below fold",'
        '"confidence":1.8,"evidence":["CTA is below the visible fold"]}]}'
        "\n```"
    )

    assert result.findings[0].finding_id == "f1"
    assert result.findings[0].confidence == 1.0


def test_vision_result_rejects_empty_findings_without_summary() -> None:
    result = parse_vision_result('{"findings":[]}')

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"
    assert "summary" in result.error["message"]


def test_vision_result_rejects_findings_without_image_or_dom_evidence() -> None:
    result = parse_vision_result(
        '{"summary":"bad CTA","findings":[{"id":"f1",'
        '"severity":"high","category":"layout","problem":"below fold",'
        '"confidence":0.8,"evidence":[]}]}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"
    assert "evidence" in result.error["message"]


def test_dom_vision_result_preserves_observation_hypothesis_uncertainty() -> None:
    result = parse_vision_result(
        '{"findings":[{"id":"f1","severity":"high","category":"layout",'
        '"problem":"CTA hidden","observed":"display is none",'
        '"hypothesized":"hydration rule hides CTA",'
        '"uncertainty":["runtime state not captured"],"confidence":0.8,'
        '"evidence":["computed style"]}]}',
        require_observation_fields=True,
    )

    assert result.terminal is False
    finding = result.findings[0]
    assert finding.observed == "display is none"
    assert finding.hypothesized == "hydration rule hides CTA"
    assert finding.uncertainty == ("runtime state not captured",)
    assert finding.evidence == ("computed style",)


@pytest.mark.parametrize("missing", ["observed", "hypothesized", "uncertainty"])
def test_dom_vision_result_rejects_missing_observation_contract(missing: str) -> None:
    finding = {
        "id": "f1",
        "severity": "high",
        "category": "layout",
        "problem": "CTA hidden",
        "observed": "display is none",
        "hypothesized": "hydration rule hides CTA",
        "uncertainty": ["runtime state not captured"],
        "confidence": 0.8,
        "evidence": ["computed style"],
    }
    del finding[missing]

    result = parse_vision_result(
        '{"findings":[' + str(finding).replace("'", '"') + "]}",
        require_observation_fields=True,
    )

    assert result.terminal is True
    assert missing in result.error["message"]


@pytest.mark.parametrize("field", ["observed", "hypothesized"])
def test_dom_vision_result_rejects_non_string_observation_fields(field: str) -> None:
    result = parse_vision_result(
        '{\"findings\":[{\"id\":\"f1\",\"severity\":\"high\",\"category\":\"layout\",'
        '\"problem\":\"CTA hidden\",\"observed\":\"display is none\",'
        '\"hypothesized\":\"hydration rule hides CTA\",'
        '\"uncertainty\":[],\"confidence\":0.8,'
        '\"' + field + '\":42}]}',
        require_observation_fields=True,
    )

    assert result.terminal is True
    assert field in result.error["message"]


@pytest.mark.parametrize("missing", ["id", "problem", "confidence"])
def test_vision_result_rejects_missing_required_finding_fields(missing: str) -> None:
    finding = {
        "id": "f1",
        "severity": "high",
        "category": "layout",
        "problem": "below fold",
        "confidence": 0.5,
        "evidence": ["CTA appears below the visible fold"],
    }
    del finding[missing]

    result = parse_vision_result('{"summary":"bad","findings":[' + str(finding).replace("'", '"') + "]}")

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"


def test_vision_result_clamps_confidence_at_zero() -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"low",'
        '"category":"layout","problem":"bad","confidence":-0.5,'
        '"evidence":["visible layout issue"]}]}'
    )

    assert result.findings[0].confidence == 0.0


@pytest.mark.parametrize("confidence", ["NaN", "Infinity", "-Infinity"])
def test_vision_result_rejects_non_finite_confidence(confidence: str) -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"low",'
        + '"category":"layout","problem":"bad","confidence":' + confidence + "}]}"
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"


@pytest.mark.parametrize("confidence", ['"0.8"', "true"])
def test_vision_result_rejects_non_numeric_confidence(confidence: str) -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"low",'
        '"category":"layout","problem":"bad","confidence":' + confidence +
        ',"evidence":["visible layout issue"]}]}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"
    assert "confidence" in result.error["message"]


@pytest.mark.parametrize(("field", "value"), [("id", 4), ("problem", 404)])
def test_vision_result_rejects_non_string_required_text(
    field: str, value: int
) -> None:
    finding = {
        "id": "f1",
        "severity": "low",
        "category": "layout",
        "problem": "bad",
        "confidence": 0.5,
        "evidence": ["visible layout issue"],
    }
    finding[field] = value
    result = parse_vision_result(json.dumps({"summary": "review", "findings": [finding]}))

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"
    assert field in result.error["message"]


@pytest.mark.parametrize("coordinate", ['"0.25"', "true"])
def test_vision_result_requires_numeric_bbox_coordinates(coordinate: str) -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"low",'
        '"category":"layout","problem":"bad","confidence":0.5,'
        '"evidence":["visible layout issue"],"bbox":[' + coordinate + ',0.1,0.2,0.3]}]}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"
    assert "bbox coordinates" in result.error["message"]


def test_vision_result_rejects_non_finite_bbox_coordinates() -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"low",'
        '"category":"layout","problem":"bad","confidence":0.5,'
        '"bbox":[0, 1, 2, Infinity]}]}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"


@pytest.mark.parametrize("field", ["unknowns", "recommended_checks"])
def test_vision_result_rejects_malformed_optional_lists(field: str) -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[],"' + field + '":"not-a-list"}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"


def test_successful_vision_result_has_non_terminal_invariants() -> None:
    result = parse_vision_result(
        '{"schema_version":"1","summary":"ok","findings":[],'
        '"unknowns":["no DOM"],"recommended_checks":["run tests"]}'
    )

    assert result.terminal is False
    assert result.error == {}
    assert result.findings == ()
    assert result.unknowns == ("no DOM",)
    assert result.recommended_checks == ("run tests",)


@pytest.mark.parametrize("field", ["element_ids", "evidence"])
def test_vision_result_rejects_string_sequence_fields(field: str) -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"low",'
        '"category":"layout","problem":"bad","confidence":0.5,"'
        + field
        + '":"not-a-list"}]}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"


def test_vision_result_rejects_unknown_severity() -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"urgent",'
        '"category":"layout","problem":"bad","confidence":0.5,'
        '"evidence":["visible layout issue"]}]}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"
    assert "severity" in result.error["message"]


def test_vision_result_rejects_unknown_category_as_terminal_failure() -> None:
    result = parse_vision_result(
        '{"summary":"bad","findings":[{"id":"f1","severity":"high",'
        '"category":"content", "problem":"bad","confidence":0.5,'
        '"evidence":["visible content issue"]}]}'
    )

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"
    assert "category" in result.error["message"]


def test_malformed_vision_result_is_terminal_structured_failure() -> None:
    result = parse_vision_result("not JSON")

    assert result.terminal is True
    assert result.error["code"] == "malformed_vision_output"


def test_coder_packet_keeps_referenced_dom_ancestors_and_bounded_runtime() -> None:
    packet = build_coder_packet(
        prompt="Fix mobile checkout",
        findings=[{"id": "f1", "element_ids": ["el-42"]}],
        dom={
            "elements": [
                {"element_id": "root", "ancestor_ids": []},
                {"element_id": "parent", "ancestor_ids": ["root"]},
                {"element_id": "el-42", "ancestor_ids": ["root", "parent"]},
                {"element_id": "other", "ancestor_ids": ["root"]},
            ]
        },
        repo_context={"files": ["src/Checkout.tsx"]},
        runtime_context={"console": ["error", "error"], "network": ["failed", "failed"]},
        max_runtime_items=2,
    )

    assert [element["element_id"] for element in packet["dom"]["elements"]] == [
        "root",
        "parent",
        "el-42",
    ]
    assert packet["runtime"]["console"] == ["error", "error"]
    assert packet["repo"] == {"files": ["src/Checkout.tsx"]}


def test_coder_packet_rejects_findings_that_reference_missing_dom_elements() -> None:
    packet = build_coder_packet(
        prompt="Review checkout",
        findings=[{"id": "f1", "element_ids": ["invented-button"]}],
        dom={"elements": [{"element_id": "real-button", "tag": "button"}]},
    )

    assert packet["terminal"] is True
    assert packet["error"]["code"] == "malformed_coder_context"
    assert "invented-button" in packet["error"]["message"]


def test_coder_packet_bounds_runtime_dict_keys_and_nested_lists() -> None:
    packet = build_coder_packet(
        prompt="Review runtime",
        findings=[],
        dom={"elements": []},
        runtime_context={"console": ["one", "two"], "network": ["one", "two"]},
        max_runtime_items=2,
    )

    assert list(packet["runtime"]) == ["console", "network"]
    assert packet["runtime"]["console"] == ["one", "two"]


def test_coder_packet_normalizes_negative_runtime_bound() -> None:
    packet = build_coder_packet(
        prompt="Review runtime",
        findings=[],
        dom={"elements": []},
        runtime_context={"console": ["error"]},
        max_runtime_items=-1,
    )

    assert packet["terminal"] is True
    assert packet["error"]["code"] == "frontend_context_too_large"


def test_coder_packet_rejects_runtime_overflow_instead_of_truncating() -> None:
    packet = build_coder_packet(
        prompt="Review runtime",
        findings=[],
        dom={"elements": []},
        runtime_context={"network": ["one", "two", "three"]},
        max_runtime_items=2,
    )

    assert packet["terminal"] is True
    assert packet["error"]["code"] == "frontend_context_too_large"


def test_coder_packet_rejects_oversized_prompt() -> None:
    packet = build_coder_packet(
        prompt="x" * 2_001,
        findings=[],
        dom={"elements": []},
    )

    assert packet["terminal"] is True
    assert packet["error"]["code"] == "frontend_context_too_large"


@pytest.mark.parametrize("dom", [{"elements": [None]}, {"elements": "not-a-list"}])
def test_coder_packet_reports_malformed_dom_as_terminal_failure(dom: dict) -> None:
    packet = build_coder_packet(prompt="Review DOM", findings=[], dom=dom)

    assert packet["terminal"] is True
    assert packet["error"]["code"] == "malformed_coder_context"


def test_coder_packet_reports_none_findings_as_terminal_failure() -> None:
    packet = build_coder_packet(prompt="Review", findings=None, dom={"elements": []})

    assert packet["terminal"] is True
    assert packet["error"]["code"] == "malformed_coder_context"


@pytest.mark.parametrize("runtime_context", [[], "", 0])
def test_coder_packet_reports_falsey_non_mapping_runtime_as_terminal_failure(
    runtime_context: object,
) -> None:
    packet = build_coder_packet(
        prompt="Review runtime",
        findings=[],
        dom={"elements": []},
        runtime_context=runtime_context,
    )

    assert packet["terminal"] is True
    assert packet["error"]["code"] == "malformed_coder_context"
