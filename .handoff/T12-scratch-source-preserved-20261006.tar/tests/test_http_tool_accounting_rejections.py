from local_ai_hub import http_server


def test_tool_accounting_reports_aggregate_rejections_without_exception_details(monkeypatch):
    class Telemetry:
        def record_tool_accounting(self, event):
            if event["kind"] == "invalid":
                raise ValueError("sensitive prompt text")
            if event["kind"] == "failed":
                raise RuntimeError("private source text")

    class App:
        telemetry = Telemetry()

    handler = http_server.Handler.__new__(http_server.Handler)
    handler.path = "/api/telemetry/tool-accounting"
    handler.headers = {"Content-Type": "application/json"}
    handler._begin_trace = lambda path: None
    handler._require_authorized = lambda: True
    handler._read_json = lambda: {
        "events": [{"kind": "accepted"}, {"kind": "invalid"}, {"kind": "failed"}]
    }
    handler._validate_payload = lambda path, payload: None
    responses = []
    handler._send = lambda status, data: responses.append((status, data))
    monkeypatch.setattr(http_server, "APP", App())

    handler.do_POST()

    assert responses == [
        (
            200,
            {
                "success": True,
                "accepted": 1,
                "rejected": 2,
                "rejection_reasons": {"invalid_event": 1, "record_failed": 1},
            },
        )
    ]
    assert "sensitive prompt text" not in str(responses)
    assert "private source text" not in str(responses)
