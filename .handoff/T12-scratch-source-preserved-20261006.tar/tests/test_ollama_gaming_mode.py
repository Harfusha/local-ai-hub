from __future__ import annotations

import time
from pathlib import Path

import pytest

from local_ai_hub.ollama import OllamaRuntime


def _runtime(tmp_path: Path) -> OllamaRuntime:
    return OllamaRuntime(
        {
            "server": {
                "state_dir": str(tmp_path),
                "ollama_url": "http://127.0.0.1:11434",
                "request_timeout_seconds": 1.0,
            },
            "ollama": {"enabled": True, "request_attempts": 1},
            "models": {
                "fast_code": "configured-fast",
                "heavy_code": "configured-heavy",
                "embedding": "configured-embedding",
                "embedding_backend": "sentence-transformers",
                "embedding_device": "cpu",
            },
            "ollama_subagents": {
                "profiles": {"drafter": {"model": "configured-subagent"}},
            },
            "llama_cpp": {"fallback_to_ollama": True, "models": {}},
        }
    )


def test_pause_unloads_only_configured_loaded_models_without_loading_models(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime = _runtime(tmp_path)
    requests: list[tuple[str, dict | None, float | None, float | None]] = []

    def request(endpoint, payload=None, timeout=None, *, should_stop=None, deadline=None):
        requests.append((endpoint, payload, timeout, deadline))
        if endpoint == "/api/ps":
            return {
                "models": [
                    {"name": "configured-fast"},
                    {"name": "configured-subagent"},
                    {"name": "unconfigured-external"},
                ]
            }
        if endpoint == "/api/generate":
            return {"done": True, "done_reason": "unload"}
        pytest.fail(f"pause must not call {endpoint}")

    monkeypatch.setattr(runtime, "request", request)
    monkeypatch.setattr(runtime, "load_model", lambda *_a, **_k: pytest.fail("pause must not load a model"))
    monkeypatch.setattr(runtime, "ensure_running", lambda *_a, **_k: pytest.fail("pause must not start a backend"))

    result = runtime.unload_configured_models(timeout_seconds=0.5)

    assert result == {
        "success": True,
        "backend_available": True,
        "unloaded": ["configured-fast", "configured-subagent"],
        "failed": {},
    }
    unloads = [(endpoint, payload) for endpoint, payload, _timeout, _deadline in requests if endpoint != "/api/ps"]
    assert [endpoint for endpoint, _payload in unloads] == ["/api/generate", "/api/generate"]
    assert [payload["model"] for _endpoint, payload in unloads] == ["configured-fast", "configured-subagent"]
    assert all(payload.get("prompt", "") == "" for _endpoint, payload in unloads)
    assert all(payload["keep_alive"] == 0 for _endpoint, payload in unloads)
    assert all(deadline is not None for _endpoint, _payload, _timeout, deadline in requests)


def test_pause_does_not_report_unload_without_backend_confirmation(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime = _runtime(tmp_path)

    def request(endpoint, payload=None, timeout=None, *, should_stop=None, deadline=None):
        if endpoint == "/api/ps":
            return {"models": [{"name": "configured-fast"}]}
        if endpoint == "/api/generate":
            return {"done": True, "done_reason": "stop"}
        pytest.fail(f"pause must not call {endpoint}")

    monkeypatch.setattr(runtime, "request", request)

    result = runtime.unload_configured_models(timeout_seconds=0.5)

    assert result == {
        "success": False,
        "backend_available": True,
        "unloaded": [],
        "failed": {"configured-fast": "unload failed or timed out"},
    }


def test_pause_is_idempotent_when_no_configured_models_are_loaded(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime = _runtime(tmp_path)
    endpoints: list[str] = []

    def request(endpoint, payload=None, timeout=None, *, should_stop=None, deadline=None):
        endpoints.append(endpoint)
        if endpoint == "/api/ps":
            return {"models": [{"name": "unconfigured-external"}]}
        pytest.fail(f"no model unload is needed; got {endpoint}")

    monkeypatch.setattr(runtime, "request", request)

    first = runtime.unload_configured_models(timeout_seconds=0.5)
    second = runtime.unload_configured_models(timeout_seconds=0.5)

    assert first == second == {
        "success": True,
        "backend_available": True,
        "unloaded": [],
        "failed": {},
    }
    assert endpoints == ["/api/ps", "/api/ps"]


def test_pause_reports_backend_unavailable_with_a_shared_deadline(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime = _runtime(tmp_path)
    calls: list[tuple[str, float | None, float | None]] = []
    started = time.monotonic()

    def request(endpoint, payload=None, timeout=None, *, should_stop=None, deadline=None):
        calls.append((endpoint, timeout, deadline))
        return {"error": "backend unavailable"}

    monkeypatch.setattr(runtime, "request", request)
    monkeypatch.setattr(runtime, "ensure_running", lambda *_a, **_k: pytest.fail("pause must not start a backend"))

    result = runtime.unload_configured_models(timeout_seconds=0.2)

    assert result["success"] is False
    assert result["backend_available"] is False
    assert result["unloaded"] == []
    assert "backend" in result["failed"]
    assert [endpoint for endpoint, _timeout, _deadline in calls] == ["/api/ps"]
    assert calls[0][1] is not None and calls[0][1] <= 0.2
    assert calls[0][2] is not None and calls[0][2] - started <= 0.25


def test_pause_reports_unload_timeout_without_loading_models(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime = _runtime(tmp_path)
    requests: list[tuple[str, dict | None, float | None, float | None]] = []

    def request(endpoint, payload=None, timeout=None, *, should_stop=None, deadline=None):
        requests.append((endpoint, payload, timeout, deadline))
        if endpoint == "/api/ps":
            return {"models": [{"name": "configured-fast"}]}
        return {"error": "unload request timed out", "timed_out": True}

    monkeypatch.setattr(runtime, "request", request)
    monkeypatch.setattr(runtime, "load_model", lambda *_a, **_k: pytest.fail("pause must not load a model"))

    result = runtime.unload_configured_models(timeout_seconds=0.2)

    assert result["success"] is False
    assert result["backend_available"] is True
    assert result["unloaded"] == []
    assert "configured-fast" in result["failed"]
    assert [endpoint for endpoint, _payload, _timeout, _deadline in requests] == ["/api/ps", "/api/generate"]
