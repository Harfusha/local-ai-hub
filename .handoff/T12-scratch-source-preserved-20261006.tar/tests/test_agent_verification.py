from __future__ import annotations

from pathlib import Path
from dataclasses import replace
import pytest

from local_ai_hub.agent_events import AgentStateStore
from local_ai_hub.artifacts import ArtifactStore
from local_ai_hub.agent_identity import ScopeContext
from local_ai_hub.agent_tasks import CompletionGateError, GoalContract, TaskCheckpoint, TaskStore
from local_ai_hub.agent_verification import (
    ChangeIntent,
    CompletionResult,
    OutcomeRecord,
    VerificationReceipt,
    VerificationStore,
    criterion_evidence_type,
)
from local_ai_hub.agent_consistency import AgentConsistencyGuard, ConsistencyRequest, GuardWarning
from local_ai_hub.agent_memory import MemoryStore
from local_ai_hub.repo_tools import RepositoryTools
from local_ai_hub.sqlite_support import connect_sqlite


@pytest.fixture
def stores(tmp_path: Path) -> tuple[TaskStore, VerificationStore]:
    state_store = AgentStateStore(tmp_path / "agent_state.sqlite3")
    task_store = TaskStore(state_store)
    artifact_store = ArtifactStore(tmp_path / "artifacts")
    verif_store = VerificationStore(state_store, task_store=task_store, artifact_store=artifact_store)
    return task_store, verif_store


def receipt_for(
    task_id: str,
    criterion: str,
    passed: bool = True,
    expires_at: float | None = None,
    *,
    owner: str = "agent",
    repository_revision: str = "rev-1",
    mutation_generation: int = 0,
    evidence_type: str | None = None,
    artifact_store: ArtifactStore | None = None,
) -> VerificationReceipt:
    kind = evidence_type or criterion_evidence_type(criterion)
    command_id = "cmd-123" if kind in {"test", "benchmark"} else ""
    evidence_id = "ev-123"
    if passed is True and artifact_store is not None:
        proof = {
            "kind": "work_command_verification" if command_id else "work_source_review",
            "passed": True,
            "task_id": task_id,
            "owner": owner,
            "repository_revision": repository_revision,
            "mutation_generation": mutation_generation,
        }
        if command_id:
            proof.update(
                criterion=criterion,
                command_id=command_id,
                exit_code=0,
                result={"success": True, "exit_code": 0},
            )
        else:
            proof["criteria"] = [criterion]
        evidence_id = artifact_store.put_json(
            proof, owner, "command_verification" if command_id else "source_review"
        )
    return VerificationReceipt.create(
        task_id=task_id,
        criterion=criterion,
        passed=passed,
        expires_at=expires_at,
        evidence_id=evidence_id,
        command_id=command_id,
        owner=owner,
        repository_revision=repository_revision,
        mutation_generation=mutation_generation,
        evidence_type=kind,
    )


def test_stale_receipt_cannot_satisfy_completion(stores: tuple[TaskStore, VerificationStore]):
    task_store, verif_store = stores
    task = task_store.create(
        GoalContract(goal="test task", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-1"),
        task_id="task-1",
    )
    verif_store.record(receipt_for("task-1", "tests", expires_at=10.0, artifact_store=verif_store.artifact_store))
    # Check at now=11: expired!
    res = verif_store.completion("task-1", now=11.0)
    assert res.complete is False
    assert "tests" in res.stale_criteria

    # Check at now=9: fresh!
    res_fresh = verif_store.completion("task-1", now=9.0)
    assert res_fresh.complete is True
    assert "tests" in res_fresh.satisfied_criteria


def test_revert_is_explicit_negative_outcome(stores: tuple[TaskStore, VerificationStore]):
    _, verif_store = stores
    outcome = verif_store.record_outcome(OutcomeRecord.reverted("change-1", actor="user"))
    assert outcome.kind == "reverted"
    assert outcome.actor == "user"


def test_verification_store_record_methods_are_noops_when_agent_state_disabled(tmp_path: Path):
    state_store = AgentStateStore(tmp_path / "disabled.sqlite3", enabled=False)
    store = VerificationStore(state_store)
    receipt = receipt_for("disabled-task", "tests")
    change = ChangeIntent.create("disabled-task", ("src/app.py",))
    outcome = OutcomeRecord.accepted(change.change_id, task_id="disabled-task")

    assert store.record(receipt) is receipt
    assert store.record_change(change) is change
    assert store.record_outcome(outcome) is outcome
    assert not state_store.db_path.exists()


@pytest.mark.parametrize(
    ("task_id", "criterion"),
    [("", "tests"), ("task-1", "")],
)
def test_verification_receipts_require_task_and_criterion(task_id: str, criterion: str):
    with pytest.raises(ValueError, match="requires"):
        VerificationReceipt.create(task_id, criterion)


def test_passed_verification_receipt_requires_evidence_id():
    with pytest.raises(ValueError, match="evidence_id"):
        VerificationReceipt.create("task-proof", "tests", evidence_id=" ")


def test_verifier_exception_cannot_become_a_passing_receipt(
    stores: tuple[TaskStore, VerificationStore],
):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="verifier exception", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-verifier-exception"),
        task_id="task-verifier-exception",
    )

    try:
        raise RuntimeError("verifier unavailable")
    except RuntimeError as error:
        verifier_result = error

    receipt = VerificationReceipt.create(
        "task-verifier-exception",
        "tests",
        passed=verifier_result,
        evidence_id="ev-verifier-error",
    )
    assert receipt.passed is False

    verif_store.record(receipt)
    completion = verif_store.completion("task-verifier-exception")
    assert completion.complete is False
    assert "tests" in completion.unsatisfied_criteria


def test_explicit_verifier_failure_cannot_satisfy_completion(
    stores: tuple[TaskStore, VerificationStore],
):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="verifier failure", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-verifier-failure"),
        task_id="task-verifier-failure",
    )

    receipt = VerificationReceipt.create(
        "task-verifier-failure", "tests", passed=False, evidence_id="ev-failed"
    )
    verif_store.record(receipt)

    completion = verif_store.completion("task-verifier-failure")
    assert receipt.passed is False
    assert completion.complete is False
    assert "tests" in completion.unsatisfied_criteria


def test_completion_rejects_receipt_missing_from_store(stores: tuple[TaskStore, VerificationStore]):
    task_store, _ = stores
    task_store.create(
        GoalContract(goal="missing receipt", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-missing"),
        task_id="task-missing",
    )
    task_store.add_verification_receipt("task-missing", "tests", "missing-row")

    with pytest.raises(CompletionGateError, match="missing-row"):
        task_store.complete("task-missing")


@pytest.mark.parametrize(
    ("receipt_task_id", "receipt_criterion"),
    [("other-task", "tests"), ("task-mismatch", "lint")],
)
def test_completion_rejects_receipt_with_mismatched_identity(
    stores: tuple[TaskStore, VerificationStore],
    receipt_task_id: str,
    receipt_criterion: str,
):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="identity check", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-mismatch"),
        task_id="task-mismatch",
    )
    receipt = receipt_for(receipt_task_id, receipt_criterion, artifact_store=verif_store.artifact_store)
    verif_store.record(receipt)
    task_store.add_verification_receipt("task-mismatch", "tests", receipt.receipt_id)

    with pytest.raises(CompletionGateError, match="task-mismatch|criterion"):
        task_store.complete("task-mismatch")


def test_completion_fails_closed_and_preserves_receipt_lookup_error(
    stores: tuple[TaskStore, VerificationStore], monkeypatch: pytest.MonkeyPatch
):
    task_store, _ = stores
    task_store.create(
        GoalContract(goal="database failure", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-db-error"),
        task_id="task-db-error",
    )
    task_store.add_verification_receipt("task-db-error", "tests", "receipt-db-error")

    from local_ai_hub.sqlite_support import connect_sqlite

    class FailingReceiptLookup:
        def __init__(self, connection):
            self.connection = connection

        def execute(self, query, *args, **kwargs):
            if "agent_verification_receipts" in query:
                raise RuntimeError("receipt database unavailable")
            return self.connection.execute(query, *args, **kwargs)

        def close(self):
            self.connection.close()

        def __getattr__(self, name):
            return getattr(self.connection, name)

    def fail_lookup(*args, **kwargs):
        return FailingReceiptLookup(connect_sqlite(*args, **kwargs))

    monkeypatch.setattr("local_ai_hub.agent_tasks.connect_sqlite", fail_lookup)
    with pytest.raises(CompletionGateError, match="receipt-db-error") as error:
        task_store.complete("task-db-error")

    assert isinstance(error.value.__cause__, RuntimeError)
    assert "receipt database unavailable" in str(error.value.__cause__)


def test_failed_receipt_storage_cannot_satisfy_completion(
    stores: tuple[TaskStore, VerificationStore], monkeypatch: pytest.MonkeyPatch
):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="storage failure", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-store-error"),
        task_id="task-store-error",
    )

    def fail_store(*args, **kwargs):
        raise RuntimeError("receipt write failed")

    monkeypatch.setattr("local_ai_hub.agent_verification.connect_sqlite", fail_store)
    with pytest.raises(RuntimeError, match="receipt write failed"):
        verif_store.record(receipt_for("task-store-error", "tests", artifact_store=verif_store.artifact_store))
    monkeypatch.undo()

    with pytest.raises(CompletionGateError, match="tests"):
        task_store.complete("task-store-error")


def test_valid_receipt_allows_task_completion(stores: tuple[TaskStore, VerificationStore]):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="valid proof", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-valid"),
        task_id="task-valid",
    )
    receipt = receipt_for("task-valid", "tests", artifact_store=verif_store.artifact_store)
    verif_store.record(receipt)

    completed = task_store.complete("task-valid")

    assert completed.status.value == "completed"
    assert completed.verification_receipts["tests"] == receipt.receipt_id


def test_verification_store_prunes_legacy_invalid_receipts(tmp_path: Path):
    state_store = AgentStateStore(tmp_path / "legacy.sqlite3")
    VerificationStore(state_store)
    con = connect_sqlite(state_store.db_path)
    try:
        con.execute(
            "INSERT INTO agent_verification_receipts "
            "(receipt_id, task_id, criterion, change_intent_id, evidence_id, command_id, "
            "repository_revision, observed_at, expires_at, passed, details) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("legacy-invalid", "task-legacy", "", "", "", "", "", 1.0, None, 1, "{}"),
        )
    finally:
        con.close()

    VerificationStore(state_store)
    con = connect_sqlite(state_store.db_path)
    try:
        assert con.execute(
            "SELECT 1 FROM agent_verification_receipts WHERE receipt_id=?",
            ("legacy-invalid",),
        ).fetchone() is None
    finally:
        con.close()


def test_current_revision_rejects_fresh_receipt_from_other_revision(stores: tuple[TaskStore, VerificationStore]):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="revision task", acceptance_criteria=("tests",)),
        ScopeContext(task_id="revision-task"),
        task_id="revision-task",
    )
    verif_store.record(receipt_for(
        "revision-task", "tests", artifact_store=verif_store.artifact_store,
        repository_revision="old-revision", expires_at=100.0,
    ))

    result = verif_store.completion("revision-task", now=50.0, current_revision="new-revision")

    assert result.complete is False
    assert result.satisfied_criteria == ()
    assert result.stale_criteria == ("tests",)


def test_all_criteria_must_pass_for_completion(stores: tuple[TaskStore, VerificationStore]):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="two criteria", acceptance_criteria=("tests", "lint")),
        ScopeContext(task_id="task-2"),
        task_id="task-2",
    )
    verif_store.record(receipt_for("task-2", "tests", passed=True, artifact_store=verif_store.artifact_store))
    verif_store.record(receipt_for("task-2", "lint", passed=False, artifact_store=verif_store.artifact_store))

    comp = verif_store.completion("task-2", now=100.0)
    assert comp.complete is False
    assert "lint" in comp.unsatisfied_criteria
    assert "tests" in comp.satisfied_criteria


def test_newer_failed_receipt_supersedes_older_pass(stores: tuple[TaskStore, VerificationStore]):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="latest receipt wins", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-latest-receipt"),
        task_id="task-latest-receipt",
    )
    passing = replace(
        receipt_for("task-latest-receipt", "tests", artifact_store=verif_store.artifact_store),
        observed_at=10.0,
    )
    failing = VerificationReceipt.create(
        "task-latest-receipt", "tests", passed=False, owner="agent",
        command_id="cmd-failed", evidence_type="test",
    )
    failing = replace(failing, observed_at=20.0)
    verif_store.record(passing)
    verif_store.record(failing)

    completion = verif_store.completion("task-latest-receipt", now=30.0)

    assert completion.complete is False
    assert completion.unsatisfied_criteria == ("tests",)
    assert completion.receipts[0].receipt_id == failing.receipt_id


def test_completion_rejects_receipt_from_previous_mutation_generation(
    stores: tuple[TaskStore, VerificationStore],
):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="changed task", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-generation"),
        task_id="task-generation",
    )
    receipt = receipt_for(
        "task-generation", "tests", artifact_store=verif_store.artifact_store,
        mutation_generation=0,
    )
    verif_store.record(receipt)
    task_store.checkpoint(
        "task-generation",
        TaskCheckpoint(state_data={"mutation_generation": 1}),
        actor="agent", idempotency_key="changed-generation",
    )

    completion = verif_store.completion("task-generation", now=receipt.observed_at + 1)

    assert completion.complete is False
    assert completion.stale_criteria == ("tests",)


def test_completion_audit_maps_criteria_to_evidence_and_receipts(stores: tuple[TaskStore, VerificationStore], tmp_path: Path):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="audited task", acceptance_criteria=("tests", "lint")),
        ScopeContext(task_id="task-audit"),
        task_id="task-audit",
    )
    verif_store.record(receipt_for("task-audit", "tests", artifact_store=verif_store.artifact_store, repository_revision="rev-1"))
    verif_store.record(receipt_for("task-audit", "lint", artifact_store=verif_store.artifact_store, repository_revision="rev-1"))
    guard = AgentConsistencyGuard(RepositoryTools({}), verification_store=verif_store)

    result = verif_store.completion(
        "task-audit",
        repository_revision="rev-1",
        include_consistency=True,
        consistency_guard=guard,
        warnings=(GuardWarning("info", "reuse", "reused existing symbol", ("ev-tests",)),),
    )
    audit = result.to_dict()["consistency"]

    assert result.complete is True
    test_receipt = next(receipt for receipt in result.receipts if receipt.criterion == "tests")
    assert audit["criteria"]["tests"]["evidence_ids"] == [test_receipt.evidence_id]
    assert audit["criteria"]["lint"]["receipt_ids"] == [result.receipts[0].receipt_id] or audit["criteria"]["lint"]["receipt_ids"]
    assert audit["current_revision_receipt_coverage"]["covered"] == 2
    assert audit["current_revision_receipt_coverage"]["total"] == 2
    assert audit["drift_warnings"][0]["code"] == "reuse"


def test_completion_audit_reports_unresolved_contract_mismatch(stores: tuple[TaskStore, VerificationStore], tmp_path: Path):
    task_store, verif_store = stores
    task_store.create(
        GoalContract(goal="contract task", acceptance_criteria=("tests",)),
        ScopeContext(task_id="task-contract"),
        task_id="task-contract",
    )
    verif_store.record(receipt_for("task-contract", "tests", artifact_store=verif_store.artifact_store, repository_revision="rev-2"))
    guard = AgentConsistencyGuard(RepositoryTools({}), verification_store=verif_store)

    result = verif_store.completion(
        "task-contract",
        repository_revision="rev-2",
        include_consistency=True,
        consistency_guard=guard,
        mappings=(
            {"kind": "response", "status": "mismatch", "evidence_ids": ["ev-contract"], "mismatches": ["name"]},
        ),
        warnings=(GuardWarning("warning", "response_schema_mismatch", "schema differs", ("ev-contract",)),),
    )
    audit = result.to_dict()["consistency"]

    assert result.complete is True
    assert audit["contract_mismatches"][0]["code"] == "response_schema_mismatch"
    assert audit["unsupported_claims"] == []
    assert audit["warnings"]
