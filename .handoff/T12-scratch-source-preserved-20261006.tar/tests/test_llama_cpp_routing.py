from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from local_ai_hub.hardware import profile_overrides
from local_ai_hub.llama_cpp import LlamaCppRouter, _loopback_url
from local_ai_hub.ollama import OllamaRuntime


class _Response:
    status = 200

    def __init__(self, value: dict | None = None, lines: list[bytes] | None = None):
        self.value = value or {}
        self.lines = lines or []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self) -> bytes:
        return json.dumps(self.value).encode("utf-8")

    def __iter__(self):
        return iter(self.lines)


class LlamaCppRoutingTests(unittest.TestCase):
    def _config(self, vendor: str = "intel", mode: str = "auto") -> dict:
        return {
            "server": {"request_timeout_seconds": 10},
            "_hardware": {"gpus": [{"vendor": vendor, "name": f"{vendor} GPU", "integrated": True}]},
            "llama_cpp": {
                "mode": mode,
                "models": {
                    "qwen2.5-coder:0.5b": {"url": "http://127.0.0.1:12438", "served_model": "hub-qwen-05", "context_length": 16384},
                    "qwen2.5-coder:1.5b": {"url": "http://127.0.0.1:12438", "served_model": "hub-qwen-15", "context_length": 32768},
                    "qwen2.5-coder:3b": {"url": "http://127.0.0.1:12438", "served_model": "hub-qwen-3", "context_length": 32768},
                    "qwen2.5-coder:7b": {"url": "http://127.0.0.1:12438", "served_model": "hub-qwen-7", "context_length": 32768},
                },
            },
        }

    def test_auto_uses_only_configured_external_loopback_endpoint_on_any_hardware(self):
        self.assertTrue(LlamaCppRouter(self._config("intel"))._hardware_allows())
        self.assertTrue(LlamaCppRouter(self._config("amd"))._hardware_allows())
        self.assertTrue(LlamaCppRouter(self._config("nvidia"))._hardware_allows())
        self.assertTrue(LlamaCppRouter(self._config("nvidia", "on"))._hardware_allows())

    def test_off_disables_route_even_when_loopback_endpoint_is_configured(self):
        config = self._config()
        config["llama_cpp"]["mode"] = "off"
        self.assertFalse(LlamaCppRouter(config)._hardware_allows())

    def test_disabled_ollama_never_becomes_implicit_provider_fallback(self):
        config = self._config(mode="auto")
        with tempfile.TemporaryDirectory() as state_dir:
            config["server"].update({"ollama_url": "http://127.0.0.1:11434", "state_dir": state_dir})
            config["ollama"] = {"enabled": False}
            config["llama_cpp"]["fallback_to_ollama"] = True
            runtime = OllamaRuntime(config)
            with patch.object(runtime.llama_cpp, "request_stream", return_value={"_lah_backend_unavailable": "endpoint offline"}), \
                 patch("local_ai_hub.ollama.urlopen", side_effect=AssertionError("disabled Ollama must not be called")):
                result = runtime.request_stream("/api/generate", {"model": "qwen2.5-coder:1.5b"}, lambda _chunk: None, timeout=1)
        self.assertIn("llama.cpp unavailable", result["error"])
        self.assertEqual(result["_lah_provider"], "llama.cpp")

    def test_enabled_ollama_takes_priority_over_llama_cpp_mode(self):
        config = self._config(mode="on")
        with tempfile.TemporaryDirectory() as state_dir:
            config["server"].update({"ollama_url": "http://127.0.0.1:11434", "state_dir": state_dir})
            config["ollama"] = {"enabled": True}
            runtime = OllamaRuntime(config)
            with patch.object(runtime.llama_cpp, "request_stream", side_effect=AssertionError("Ollama is selected")):
                with patch("local_ai_hub.ollama.urlopen", return_value=_Response(lines=[b'{"response":"ok","done":true}\n'])):
                    result = runtime.request_stream("/api/generate", {"model": "qwen2.5-coder:1.5b", "prompt": "hi"}, lambda _chunk: None, timeout=1)
        self.assertEqual(result.get("response"), "ok")

    def test_router_mode_stream_translates_generate_and_chat(self):
        router = LlamaCppRouter(self._config())
        lines = [
            b'data: {"choices":[{"delta":{"content":"PASS-27"},"finish_reason":null}]}\n',
            b'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":12,"completion_tokens":1}}\n',
            b"data: [DONE]\n",
        ]

        def fake_urlopen(req, timeout=0):
            if req.full_url.endswith("/health"):
                return _Response({"status": "ok"})
            if req.full_url.endswith("/models"):
                rows = [{"id": entry["served_model"], "status": {"value": "loaded"}} for entry in self._config()["llama_cpp"]["models"].values()]
                return _Response({"data": rows})
            if req.full_url.endswith("/" + "v1" + "/chat/completions"):
                body = json.loads(req.data.decode("utf-8"))
                self.assertEqual(body["model"], "hub-qwen-3")
                self.assertEqual(body["messages"][-1]["content"], "reply only PASS-27")
                return _Response(lines=lines)
            self.fail(f"unexpected URL: {req.full_url}")

        chunks: list[str] = []
        with patch("local_ai_hub.llama_cpp.urlopen", side_effect=fake_urlopen):
            result = router.request_stream(
                "/api/generate",
                {"model": "qwen2.5-coder:3b", "system": "be exact", "prompt": "reply only PASS-27", "options": {"num_predict": 8, "temperature": 0}},
                chunks.append,
                timeout=2,
            )
        self.assertEqual(result["response"], "PASS-27")
        self.assertEqual(result["prompt_eval_count"], 12)
        self.assertEqual(chunks, ["PASS-27"])
        self.assertEqual(result["_lah_provider"], "llama.cpp-sycl")

    def test_preprocessing_model_uses_stable_half_billion_alias(self):
        router = LlamaCppRouter(self._config())
        lines = [
            b'data: {"choices":[{"delta":{"content":"PREPROCESS-OK"},"finish_reason":null}]}\n',
            b'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n',
            b"data: [DONE]\n",
        ]

        def fake_urlopen(req, timeout=0):
            if req.full_url.endswith("/health"):
                return _Response({"status": "ok"})
            if req.full_url.endswith("/models"):
                rows = [{"id": entry["served_model"], "status": {"value": "loaded"}} for entry in self._config()["llama_cpp"]["models"].values()]
                return _Response({"data": rows})
            if req.full_url.endswith("/" + "v1" + "/chat/completions"):
                body = json.loads(req.data.decode("utf-8"))
                self.assertEqual(body["model"], "hub-qwen-05")
                return _Response(lines=lines)
            self.fail(f"unexpected URL: {req.full_url}")

        with patch("local_ai_hub.llama_cpp.urlopen", side_effect=fake_urlopen):
            result = router.request_stream(
                "/api/generate",
                {"model": "qwen2.5-coder:0.5b", "prompt": "brief factual card", "options": {"num_predict": 8}},
                lambda _text: None,
                timeout=2,
            )
        self.assertEqual(result["response"], "PREPROCESS-OK")
        self.assertEqual(result["_lah_provider"], "llama.cpp-sycl")

    def test_router_tool_call_arguments_are_returned_in_ollama_shape(self):
        router = LlamaCppRouter(self._config())
        lines = [
            b'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"c1","function":{"name":"local_ai_repo","arguments":"{\\\"action\\\":\\\"search\\\"}"}}]},"finish_reason":null}]}\n',
            b'data: {"choices":[{"delta":{},"finish_reason":"tool_calls"}]}\n',
            b"data: [DONE]\n",
        ]

        def fake_urlopen(req, timeout=0):
            if req.full_url.endswith("/health"):
                return _Response({"status": "ok"})
            if req.full_url.endswith("/models"):
                return _Response({"data": [{"id": "hub-qwen-3", "status": {"value": "loaded"}}]})
            if req.full_url.endswith("/" + "v1" + "/chat/completions"):
                return _Response(lines=lines)
            self.fail(f"unexpected URL: {req.full_url}")

        with patch("local_ai_hub.llama_cpp.urlopen", side_effect=fake_urlopen):
            result = router.request_stream("/api/chat", {"model": "qwen2.5-coder:3b", "messages": []}, lambda _text: None, timeout=2)
        call = result["message"]["tool_calls"][0]
        self.assertEqual(call["id"], "c1")
        self.assertEqual(call["function"]["name"], "local_ai_repo")
        self.assertEqual(call["function"]["arguments"], {"action": "search"})

    def test_model_capabilities_translate_llama_cpp_image_metadata(self):
        config = self._config()
        config["llama_cpp"]["models"]["qwen3-vl:4b"] = {
            "url": "http://127.0.0.1:12438",
            "served_model": "hub-qwen-vl",
            "context_length": 8192,
        }
        router = LlamaCppRouter(config)

        def fake_urlopen(req, timeout=0):
            if req.full_url.endswith("/health"):
                return _Response({"status": "ok"})
            if req.full_url.endswith("/models"):
                return _Response({"data": [{
                    "id": "hub-qwen-vl",
                    "status": {"value": "loaded"},
                    "architecture": {"input_modalities": ["text", "image"], "output_modalities": ["text"]},
                }]})
            self.fail(f"unexpected URL: {req.full_url}")

        with patch("local_ai_hub.llama_cpp.urlopen", side_effect=fake_urlopen):
            result = router.model_capabilities("qwen3-vl:4b")

        self.assertEqual(result["capabilities"], ["completion", "vision"])

    def test_show_endpoint_uses_llama_cpp_capabilities_when_ollama_disabled(self):
        with tempfile.TemporaryDirectory() as state_dir:
            config = {
                "server": {"ollama_url": "http://127.0.0.1:11434", "state_dir": state_dir},
                "ollama": {"enabled": False},
                "llama_cpp": {"fallback_to_ollama": False, "models": {}},
            }
            runtime = OllamaRuntime(config)
            runtime.llama_cpp = unittest.mock.Mock()
            runtime.llama_cpp.model_capabilities.return_value = {
                "model": "qwen3-vl:4b",
                "capabilities": ["completion", "vision"],
            }

            result = runtime.request("/api/show", {"name": "qwen3-vl:4b"})

        self.assertEqual(result["capabilities"], ["completion", "vision"])
        runtime.llama_cpp.model_capabilities.assert_called_once_with("qwen3-vl:4b")

    def test_context_over_limit_falls_back_without_sending_request(self):
        router = LlamaCppRouter(self._config())
        result = router.request_stream(
            "/api/generate",
            {"model": "qwen2.5-coder:3b", "prompt": "x", "options": {"num_ctx": 32769}},
            lambda _text: None,
        )
        self.assertIn("_lah_backend_unavailable", result)

    def test_only_loopback_endpoints_are_accepted(self):
        self.assertEqual(_loopback_url("http://127.0.0.1:12438"), "http://127.0.0.1:12438")
        self.assertEqual(_loopback_url("http://example.com:12438"), "")
        self.assertEqual(_loopback_url("http://localhost:12438/prefix"), "")

    def test_intel_integrated_profile_disables_ollama_vulkan_but_amd_keeps_it(self):
        intel = profile_overrides("integrated", {"gpus": [{"vendor": "intel", "integrated": True}], "ram": {"total_gb": 32}})
        amd = profile_overrides("integrated", {"gpus": [{"vendor": "amd", "integrated": True}], "ram": {"total_gb": 32}})
        self.assertFalse(intel["ollama"]["allow_integrated_gpu"])
        self.assertFalse(intel["ollama"]["enable_vulkan"])
        self.assertTrue(amd["ollama"]["allow_integrated_gpu"])
        self.assertTrue(amd["ollama"]["enable_vulkan"])

    def test_hardware_profiles_select_model_roles(self):
        expected_background = {
            "cpu": "qwen2.5-coder:0.5b",
            "integrated": "qwen2.5-coder:0.5b",
            "low": "qwen2.5-coder:0.5b",
            "balanced": "qwen2.5-coder:1.5b",
            "high": "qwen2.5-coder:1.5b",
            "max": "qwen2.5-coder:1.5b",
        }
        expected_fast = {
            "cpu": "qwen2.5-coder:1.5b",
            "integrated": "qwen2.5-coder:1.5b",
            "low": "qwen2.5-coder:1.5b",
            "balanced": "qwen2.5-coder:3b",
            "high": "qwen2.5-coder:3b",
            "max": "qwen2.5-coder:3b",
        }
        expected_reasoning = {
            "cpu": "qwen2.5-coder:7b",
            "integrated": "qwen2.5-coder:7b",
            "low": "qwen2.5-coder:7b",
            "balanced": "qwen3.5:9b",
            "high": "qwen3.5:9b",
            "max": "qwen3.5:9b",
        }
        expected_heavy = {
            "cpu": "qwen2.5-coder:3b",
            "integrated": "qwen2.5-coder:3b",
            "low": "qwen2.5-coder:3b",
            "balanced": "qwen2.5-coder:7b",
            "high": "qwen2.5-coder:7b",
            "max": "qwen3.5:9b",
        }
        expected_vision = {
            "cpu": "qwen3-vl:4b",
            "integrated": "qwen3-vl:4b",
            "low": "qwen3-vl:4b",
            "balanced": "qwen3.5:9b",
            "high": "qwen3.5:9b",
            "max": "qwen3.5:9b",
        }
        expected_general = {
            "cpu": "qwen2.5-coder:1.5b",
            "integrated": "qwen2.5-coder:1.5b",
            "low": "qwen2.5-coder:1.5b",
            "balanced": "qwen2.5-coder:7b",
            "high": "qwen3.5:9b",
            "max": "qwen3.5:9b",
        }
        for name in ("cpu", "integrated", "low", "balanced", "high", "max"):
            with self.subTest(profile=name):
                profile = profile_overrides(name, {"gpus": [], "ram": {"total_gb": 32}})
                self.assertEqual(profile["models"]["background_code"], expected_background[name])
                self.assertEqual(profile["models"]["fast_code"], expected_fast[name])
                self.assertEqual(profile["models"]["reasoning"], expected_reasoning[name])
                self.assertEqual(profile["models"]["heavy_code"], expected_heavy[name])
                self.assertEqual(profile["models"]["general"], expected_general[name])
                self.assertEqual(profile["models"]["vision"], expected_vision[name])


if __name__ == "__main__":
    unittest.main()
